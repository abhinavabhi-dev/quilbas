module.exports = async function (req, res) {
  if (req.method !== "POST") { res.statusCode = 405; return res.end("Method not allowed"); }
  var key = process.env.ANTHROPIC_API_KEY, code = process.env.APP_PASSCODE;
  if (!key || !code) { res.statusCode = 503; return res.end("Server is not configured"); }
  if (req.headers["x-access-code"] !== code) { res.statusCode = 401; return res.end("Unauthorized"); }
  var body = req.body;
  if (typeof body === "string") { try { body = JSON.parse(body); } catch (e) { body = {}; } }
  var prompt = body && typeof body.prompt === "string" ? body.prompt : "";
  if (!prompt || prompt.length > 60000) { res.statusCode = 400; return res.end("Bad request"); }
  var up = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 8000, stream: true, messages: [{ role: "user", content: prompt }] })
  });
  if (!up.ok || !up.body) { res.statusCode = 502; return res.end("Upstream error " + up.status); }
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  var rd = up.body.getReader(), dec = new TextDecoder(), buf = "";
  try {
    for (;;) {
      var x = await rd.read();
      if (x.done) break;
      buf += dec.decode(x.value, { stream: true });
      var lines = buf.split("\n");
      buf = lines.pop();
      for (var i = 0; i < lines.length; i++) {
        if (lines[i].indexOf("data: ") !== 0) continue;
        try {
          var j = JSON.parse(lines[i].slice(6));
          if (j.type === "content_block_delta" && j.delta && j.delta.type === "text_delta") res.write(j.delta.text);
        } catch (e) {}
      }
    }
  } catch (e) { res.write("\n[[QB_ERROR]]"); }
  res.end();
};
