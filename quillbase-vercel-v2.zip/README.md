# Quillbase on Vercel (Node only, no Python)

Put these files at the TOP LEVEL of your GitHub repo (not inside another folder):
  package.json, vercel.json, README.md, public/index.html, api/generate.js
Delete any other files from earlier uploads, especially anything ending .py, requirements.txt, pyproject.toml, Pipfile or app.py.
Those make Vercel think this is a Python project and cause PYTHON_ENTRYPOINT_NOT_FOUND.

Project settings (Settings > Build and Deployment)
- Framework Preset: Other
- Root Directory: leave empty (or the folder that holds package.json)
- Build Command / Install Command / Output Directory: leave on defaults (vercel.json sets them)

Environment variables (Settings > Environment Variables), then Redeploy
- ANTHROPIC_API_KEY  your key from console.anthropic.com
- APP_PASSCODE       a code you choose; the site asks for it once per browser
- ANTHROPIC_MODEL    optional, defaults to claude-sonnet-5-5

Credits, documents and voice files are stored in each visitor's browser.
