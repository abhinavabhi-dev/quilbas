QUILLBASE + OPENAI FOR VERCEL

Files:
- index.html: your original Quillbase site, modified to call /api/chat
- api/chat.js: secure Vercel serverless function that calls OpenAI
- vercel.json: Vercel function configuration

DEPLOY:
1. Upload/import this folder as a Vercel project (or push it to GitHub and import it).
2. In Vercel open Project -> Settings -> Environment Variables.
3. Add:
   Name: OPENAI_API_KEY
   Value: your NEW OpenAI API key
   Environments: Production, Preview, Development as needed.
4. Save, then Deploy / Redeploy.
5. Open the deployed site and test Studio -> Write article.

SECURITY:
- Do not put the key in index.html.
- Do not name it NEXT_PUBLIC_OPENAI_API_KEY.
- The API key previously pasted into chat should be revoked and replaced. Do not reuse it.

NOTES:
- This is your uploaded single-file HTML site, adapted for Vercel serverless functions.
- The frontend sends article generation, keyword suggestion, and humanize prompts to /api/chat.
- Model configured: gpt-4.1-mini. If your OpenAI account does not have access to this model, change `model` in api/chat.js to a model available to your project.
- The 10,000 credits shown in the original UI are browser-local demo credits, not enforced server-side billing limits. Add authentication and server-side rate limiting before public launch.
- Local preview requires Vercel CLI (`vercel dev`) so /api/chat is available. Opening index.html directly will not run the API route.
